insert into employees (email_address, first_name, last_name, id,age) values ('a@gd.com', 'GD', 'A', 100,18);
insert into employees (email_address, first_name, last_name, id,age) values ('b@gd.com', 'GD', 'B', 101,28);
insert into employees (email_address, first_name, last_name, id,age) values ('c@gd.com', 'GD', 'C', 102,38);
